import AffiliateCenterPage from "@/templates/AffiliateCenterPage";

export default function Page() {
    return <AffiliateCenterPage />;
}
