import HomePage from "@/templates/HomePage";

export default function Page() {
    return <HomePage />;
}
