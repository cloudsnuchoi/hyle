import CustomerListPage from "@/templates/Customers/CustomerList/CustomerListPage";

export default function Page() {
    return <CustomerListPage />;
}
