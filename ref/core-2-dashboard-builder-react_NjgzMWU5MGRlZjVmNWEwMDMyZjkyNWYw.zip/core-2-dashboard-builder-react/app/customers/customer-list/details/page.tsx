import DetailsPage from "@/templates/Customers/CustomerList/DetailsPage";

export default function Page() {
    return <DetailsPage />;
}
