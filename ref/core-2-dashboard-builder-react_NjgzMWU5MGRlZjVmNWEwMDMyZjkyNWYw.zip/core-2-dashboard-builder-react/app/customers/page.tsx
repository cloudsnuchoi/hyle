import OverviewPage from "@/templates/Customers/OverviewPage";

export default function Page() {
    return <OverviewPage />;
}
