import StatementsPage from "@/templates/Income/StatementsPage";

export default function Page() {
    return <StatementsPage />;
}
