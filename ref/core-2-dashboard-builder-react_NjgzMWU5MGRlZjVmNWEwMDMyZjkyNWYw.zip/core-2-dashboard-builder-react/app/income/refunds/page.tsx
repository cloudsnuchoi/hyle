import RefundsPage from "@/templates/Income/Refunds/RefundsPage";

export default function Page() {
    return <RefundsPage />;
}
