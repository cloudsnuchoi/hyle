import DetailsPage from "@/templates/Income/Refunds/DetailsPage";

export default function Page() {
    return <DetailsPage />;
}
