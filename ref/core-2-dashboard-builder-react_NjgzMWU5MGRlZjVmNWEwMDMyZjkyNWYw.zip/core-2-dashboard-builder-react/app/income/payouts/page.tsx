import PayoutsPage from "@/templates/Income/PayoutsPage";

export default function Page() {
    return <PayoutsPage />;
}
