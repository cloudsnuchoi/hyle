import EarningPage from "@/templates/Income/EarningPage";

export default function Page() {
    return <EarningPage />;
}
