import UpgradeToProPage from "@/templates/UpgradeToProPage";

export default function Page() {
    return <UpgradeToProPage />;
}
