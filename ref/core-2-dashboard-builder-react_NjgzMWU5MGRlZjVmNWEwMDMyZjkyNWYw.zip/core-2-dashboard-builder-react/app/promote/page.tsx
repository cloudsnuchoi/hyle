import PromotePage from "@/templates/PromotePage";

export default function Page() {
    return <PromotePage />;
}
