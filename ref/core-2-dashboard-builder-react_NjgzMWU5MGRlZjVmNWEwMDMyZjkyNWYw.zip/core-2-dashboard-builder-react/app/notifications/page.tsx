import NotificationsPage from "@/templates/Notifications";

export default function Page() {
    return <NotificationsPage />;
}
