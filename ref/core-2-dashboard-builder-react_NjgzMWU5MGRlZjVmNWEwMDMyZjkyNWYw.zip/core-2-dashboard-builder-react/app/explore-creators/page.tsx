import ExploreCreatorsPage from "@/templates/ExploreCreatorsPage";

export default function Page() {
    return <ExploreCreatorsPage />;
}
