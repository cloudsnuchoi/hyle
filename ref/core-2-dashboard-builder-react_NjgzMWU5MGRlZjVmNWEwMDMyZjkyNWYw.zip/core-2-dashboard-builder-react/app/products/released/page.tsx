import ReleasedPage from "@/templates/Products/ReleasedPage";

export default function Page() {
    return <ReleasedPage />;
}
