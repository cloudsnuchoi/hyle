import NewProductPage from "@/templates/Products/NewProductPage";

export default function Page() {
    return <NewProductPage />;
}
