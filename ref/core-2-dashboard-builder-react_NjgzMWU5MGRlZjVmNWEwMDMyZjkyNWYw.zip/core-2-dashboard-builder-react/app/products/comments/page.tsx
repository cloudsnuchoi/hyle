import CommentsPage from "@/templates/Products/CommentsPage";

export default function Page() {
    return <CommentsPage />;
}
