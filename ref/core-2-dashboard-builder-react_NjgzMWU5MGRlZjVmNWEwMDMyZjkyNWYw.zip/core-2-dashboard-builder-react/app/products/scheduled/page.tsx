import ScheduledPage from "@/templates/Products/ScheduledPage";

export default function Page() {
    return <ScheduledPage />;
}
