import OverviewPage from "@/templates/Products/OverviewPage";

export default function Page() {
    return <OverviewPage />;
}
