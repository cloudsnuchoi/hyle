import DraftsPage from "@/templates/Products/DraftsPage";

export default function Page() {
    return <DraftsPage />;
}
