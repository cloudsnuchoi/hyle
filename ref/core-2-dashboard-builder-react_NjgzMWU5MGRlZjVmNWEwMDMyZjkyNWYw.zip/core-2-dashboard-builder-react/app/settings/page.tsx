import SettingsPage from "@/templates/SettingsPage";

export default function Page() {
    return <SettingsPage />;
}
