import ShopDetailsPage from "@/templates/Shop/ShopDetailsPage";

const ShopDetails = () => {
    return <ShopDetailsPage />;
};

export default ShopDetails;
