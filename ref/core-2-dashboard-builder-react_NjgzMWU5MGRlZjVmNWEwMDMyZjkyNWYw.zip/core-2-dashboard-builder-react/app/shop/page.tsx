import ShopPage from "@/templates/Shop/ShopPage";

export default function Page() {
    return <ShopPage />;
}
