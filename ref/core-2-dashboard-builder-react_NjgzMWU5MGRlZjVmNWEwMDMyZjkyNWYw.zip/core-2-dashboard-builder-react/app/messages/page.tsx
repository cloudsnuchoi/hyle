import MessagesPage from "@/templates/MessagesPage";

export default function Page() {
    return <MessagesPage />;
}
