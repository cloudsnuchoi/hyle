export type TabsOption = {
    id: number;
    name: string;
};