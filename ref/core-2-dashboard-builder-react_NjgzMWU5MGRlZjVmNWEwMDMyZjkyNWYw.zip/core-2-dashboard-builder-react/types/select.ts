export type SelectOption = {
    id: number;
    name: string;
};