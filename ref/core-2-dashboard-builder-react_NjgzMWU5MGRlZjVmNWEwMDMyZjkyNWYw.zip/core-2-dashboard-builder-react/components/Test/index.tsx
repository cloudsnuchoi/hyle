// type TestProps = {};

// const Test = ({}: TestProps) => <div className=""></div>;
const Test = ({}) => <div className=""></div>;

export default Test;
